export default function Footer() {
    return (
        <footer className="footer">
                <p className='footer__copiright'>© 2023 SportUp</p>
        </footer>
    );
};